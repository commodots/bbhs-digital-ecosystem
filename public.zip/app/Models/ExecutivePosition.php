<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ExecutivePosition extends Model
{
    protected $fillable = ['scope_type', 'name', 'code', 'sort_order', 'is_active'];

    protected $casts = ['is_active' => 'boolean', 'sort_order' => 'integer'];

    public function assignments(): HasMany
    {
        return $this->hasMany(LeadershipAssignment::class);
    }
}
