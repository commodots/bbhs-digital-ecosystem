<script setup>
import { ArrowRight, PlayCircle } from 'lucide-vue-next';

const heroImage = '/images/bbhs/school/bbhs-school-gate.png';
</script>

<template>
    <section class="relative min-h-[650px] overflow-hidden">

        <!-- =====================================================
             BACKGROUND IMAGE
        ====================================================== -->
        <div class="absolute inset-0">

            <img
                :src="heroImage"
                alt="Baptist Boys' High School Abeokuta"
                class="h-full w-full object-cover object-center"
            />

            <!-- BBHS green overlay -->
            <div
                class="absolute inset-0"
                style="background: linear-gradient(
                    90deg,
                    rgba(0, 53, 31, 0.96) 0%,
                    rgba(0, 53, 31, 0.84) 35%,
                    rgba(0, 53, 31, 0.48) 62%,
                    rgba(0, 53, 31, 0.08) 100%
                );"
            ></div>

            <!-- subtle bottom fade -->
            <div
                class="absolute inset-x-0 bottom-0 h-32"
                style="background: linear-gradient(
                    to top,
                    rgba(0, 53, 31, 0.45),
                    transparent
                );"
            ></div>

        </div>


        <!-- =====================================================
             HERO CONTENT
        ====================================================== -->
        <div
            class="relative mx-auto flex min-h-[650px] max-w-[1440px] items-center px-6 py-20 lg:px-10"
        >

            <div class="max-w-3xl">

                <!-- Eyebrow -->
                <div
                    class="mb-5 text-sm font-bold uppercase tracking-[0.30em]"
                    style="color: #F1D36A;"
                >
                    BBHS OLD BOYS ASSOCIATION
                </div>


                <!-- Main heading -->
                <h1
                    class="text-5xl font-extrabold leading-[1.02] tracking-tight text-white sm:text-6xl lg:text-7xl"
                >
                    United by Heritage.

                    <span
                        class="block"
                        style="color: #16A34A;"
                    >
                        Driven by Purpose.
                    </span>

                    <span class="block">
                        Building Our Future.
                    </span>
                </h1>


                <!-- Description -->
                <p
                    class="mt-7 max-w-2xl text-lg leading-8 text-white/90 lg:text-xl"
                >
                    Connecting generations of Baptist Boys' High School
                    Old Boys to preserve our legacy, support our school,
                    and uplift one another.
                </p>


                <!-- CTA buttons -->
                <div class="mt-9 flex flex-wrap gap-4">

                    <a
                        href="/membership"
                        class="group inline-flex items-center gap-3 rounded-lg px-6 py-4 font-bold shadow-lg transition-all hover:-translate-y-0.5"
                        style="background-color: #D4A72C; color: #00351F;"
                    >
                        JOIN THE BROTHERHOOD

                        <ArrowRight
                            :size="19"
                            class="transition-transform group-hover:translate-x-1"
                        />
                    </a>


                    <button
                        type="button"
                        class="inline-flex items-center gap-3 rounded-lg border border-white/80 px-6 py-4 font-semibold text-white transition-all hover:bg-white hover:text-[#00351F]"
                    >
                        <PlayCircle :size="21" />

                        WATCH OUR STORY
                    </button>

                </div>


                <!-- Heritage line -->
                <div class="mt-9 flex items-center gap-4">

                    <div
                        class="h-px w-14"
                        style="background-color: #D4A72C;"
                    ></div>

                    <span class="text-sm text-white/80">
                        Founded 1923 · Abeokuta · Nulli Secundus
                    </span>

                </div>

            </div>

        </div>


        <!-- Carousel indicator -->
        <div
            class="absolute bottom-7 left-1/2 flex -translate-x-1/2 items-center gap-2"
        >
            <span
                class="h-2 w-8 rounded-full"
                style="background-color: #D4A72C;"
            ></span>

            <span class="h-2 w-2 rounded-full bg-white/60"></span>

            <span class="h-2 w-2 rounded-full bg-white/60"></span>

        </div>

    </section>
</template>