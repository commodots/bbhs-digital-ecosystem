<script setup>
import PublicLayout from '../Layouts/PublicLayout.vue';
import Hero from '../Components/Home/Hero.vue';
</script>

<template>
    <PublicLayout>
        <section class="min-h-[70vh] flex items-center bg-white">
            <div class="mx-auto max-w-7xl px-6 py-20 lg:px-8">
                <div class="max-w-4xl">
                    <p class="mb-4 text-sm font-semibold uppercase tracking-[0.25em] text-amber-600">
                        BBHS Old Boys Association
                    </p>

                    <h1 class="text-4xl font-bold tracking-tight text-green-900 sm:text-6xl">
                        United by Heritage.
                        <span class="block text-green-600">
                            Driven by Purpose.
                        </span>
                    </h1>

                    <p class="mt-6 max-w-2xl text-lg leading-8 text-gray-600">
                        Connecting generations of BBHS Old Boys, strengthening
                        lifelong relationships and building a lasting impact
                        for our school and community.
                    </p>

                    <div class="mt-10 flex flex-wrap gap-4">
                        <a
                            href="/membership"
                            class="rounded-lg bg-green-800 px-6 py-3 font-semibold text-white shadow-sm transition hover:bg-green-900"
                        >
                            Join BBHS
                        </a>

                        <a
                            href="/alumni"
                            class="rounded-lg border border-green-800 px-6 py-3 font-semibold text-green-800 transition hover:bg-green-50"
                        >
                            Find an Old Boy
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </PublicLayout>
</template>